/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp1;

/**
 *
 * @author Student
 */
public class login {
    String Password;
    String PhoneNumber;
    String UserName;  
//We are checking if username entered has an underscore ("_") and is five characters long
        public  boolean CheckUsername(String username){
            return username.contains("_") && username.length() <= 5;
        }    
        public boolean checkPasswordComplexity(String password){
         
        boolean hasCapital=false;
        boolean hasNumber=false;
        boolean hasSpecial=false;
        
        for(int i=0; i < password.length(); i++){
            char c= password.charAt(i);
            
            if(Character.isUpperCase(c)){
                hasCapital =true;
            }else if (Character.isDigit(c)){
                hasNumber = true;
            }else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
            
            }
        return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
       }
       public boolean checkCellPhonenumber(String phone) {
           return phone.startsWith("+27") && phone.length () <= 12;
       
}
       public String registerUser(String username, String password, String phoneNumber) {
if (!CheckUsername(username)) {
return "Username is not correctly formatted; please ensure that your username containsan underscore and is no more than five characters in length.";
}
if (!checkPasswordComplexity(password)) {
return "Password is not correctly formatted; please ensure that the password contains atleast eight characters, a capital letter, a number, and a special character.";
}
if (!checkCellPhonenumber(phoneNumber)) {
return "Cell phone number incorrectly formatted or does not contain international code.";
}
this.UserName = username;
this.Password = password;
this.PhoneNumber = phoneNumber;
return "User registered successfully.";
}
       
  public boolean loginUser(String username, String password) {
      return this.UserName.equals(username) && this.Password.equals(password);
      
  }
  public String returnLoginStatus(boolean success){
      if (success){
          return "Welcome" + UserName + " it is great to see you again.";
      }else{
          return "Username or password incorrect, please try again";
      }
  }
  
    
}
