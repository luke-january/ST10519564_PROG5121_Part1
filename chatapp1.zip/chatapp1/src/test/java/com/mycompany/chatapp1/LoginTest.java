
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp1;
/**
 *
 * @author Student
 */

//---------------------------------------
//These are the only imports we do for junit 4 testing
//--------------------------------------
import org.junit.jupiter.api.Test;
//This allows us to write @Test above a method
//@test tells Netbeans that thios we are doing is a unit test

import static org.junit.jupiter.api.Assertions.*;
//This import gives us access to"assertequals", "assertTrue", "AssertFalse".
//we use these to CHECK whether the code gives the correct output.

public class LoginTest {
    
    //Creating an object to test the method
    Login login =new Login();
    
    
    //========================================
    //           USERNAME TESTTTTT
    //========================================
    
    @Test
    public void testInvalidUsernameMessage() {
    /*
    The purpose of the test:
    We provide an INCORRECT username "Kyle!!!!!!".
    We expect registerUser()to return the correct ERROR MESSAGE.
    This matches the test data given in the POE.     
        */
    String result = login.registerUser("Kyle!!!!!","Ch&&sec@ke99!","+27838968976");
    
    //assertEquals chekcs if the actual result is EXACTLY the same as expected.
    assertEquals(
    "Username is not currently formatted please ensure that your username contains an underscore and is no much more than result");
    }
    
    @Test
    public void testInvalidUsernameMessageBoolean() {
          assertfalse(login.checkUserName("Kyle!!!!!"));
    }
    
    @Test
    public void testValidUsernameMessageBoolean() {
        assertTrue(login.checkUserName("Kyl_l"));
    }
    @Test
    public void testValidPasswordMessageBoolean() {
        assertTrue(login.checkPassword("Ch&&sec@ke99!"));
    }
      @Test
    public void testInValidPasswordMessageBoolean() {
        assertTrue(login.checkPassword("Password"));   
    }
     @Test
    public void testValidPhoneNumberMessageBoolean() {
        assertTrue(login.checkPhoneNumber("+27838968976"));
    }  
  @Test
    public void testInValidPhoneNumberMessageBoolean() {
        assertTrue(login.checkPhoneNumber("08966553"));  
    }

    private void assertEquals(String username_is_not_currently_formatted_pleas) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
